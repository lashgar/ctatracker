#ifndef _BOOKSIM_HPP_
#define _BOOKSIM_HPP_

#include <string>

#ifdef _WIN32_
   #pragma warning (disable: 4786)
   #include <ostream>
#endif

using namespace std;

#endif
