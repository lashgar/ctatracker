#ifndef _MISC_UTILS_HPP_
#define _MISC_UTILS_HPP_

int log_two( int x );
int powi( int x, int y );

#endif 
