#ifndef _RNG_HPP_
#define _RNG_HPP_

void   ran_start(long seed);
long   ran_next( );

void   ranf_start(long seed);
double ranf_next( );

#endif
