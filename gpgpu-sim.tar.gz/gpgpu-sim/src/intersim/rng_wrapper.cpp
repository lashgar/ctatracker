#include "rng.hpp"

#define main rng_main
#include "rng.cpp"

long ran_next( )
{
   return ran_arr_next( );
}
