#!/bin/sh
if [ ! -s trace-grid$1 ] ; then
	echo "zero file";
fi;
