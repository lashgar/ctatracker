
delt	=	delt_s
g	=	g_s
rd	=	rd_s
rv	=	rv_s
t0c	=	t0c_s
den0	=	den0_s
cpd	=	cpd_s
cpv	=	cpv_s
ep1	=	ep1_s
ep2	=	ep2_s
qmin	=	qmin_s
XLS	=	XLS_s
XLV0	=	XLV0_s
XLF0	=	XLF0_s
cliq	=	cliq_s
cice	=	cice_s
psat	=	psat_s
denr	=	denr_s

th(its:ite,kts:kte,jts:jte)     =       th_s(its:ite,kts:kte,jts:jte)    
pii(its:ite,kts:kte,jts:jte)    =       pii_s(its:ite,kts:kte,jts:jte)   
q(its:ite,kts:kte,jts:jte)      =       q_s(its:ite,kts:kte,jts:jte)     
qc(its:ite,kts:kte,jts:jte)     =       qc_s(its:ite,kts:kte,jts:jte)    
qi(its:ite,kts:kte,jts:jte)     =       qi_s(its:ite,kts:kte,jts:jte)    
qr(its:ite,kts:kte,jts:jte)     =       qr_s(its:ite,kts:kte,jts:jte)    
qs(its:ite,kts:kte,jts:jte)     =       qs_s(its:ite,kts:kte,jts:jte)    
den(its:ite,kts:kte,jts:jte)    =       den_s(its:ite,kts:kte,jts:jte)   
p(its:ite,kts:kte,jts:jte)      =       p_s(its:ite,kts:kte,jts:jte)     
delz(its:ite,kts:kte,jts:jte)   =       delz_s(its:ite,kts:kte,jts:jte)  
rain(its:ite,jts:jte)           =       rain_s(its:ite,jts:jte)
rainncv(its:ite,jts:jte)        =       rainncv_s(its:ite,jts:jte)
sr(its:ite,jts:jte)             =       sr_s(its:ite,jts:jte)
snow(its:ite,jts:jte)           =       snow_s(its:ite,jts:jte)
snowncv(its:ite,jts:jte)        =       snowncv_s(its:ite,jts:jte)

