#!/usr/local/bin/bash

#for i in SRD BKP RDC NNC BPT NN BPT BFS MMA EDS HSP ;
for i in BFS BKP BPT EDS HSP NN NNC MMA RDC SRD
do
  lower=$(echo $i | tr '[:upper:]' '[:lower:]')
  size=`cat $i/log.cta3_after_awhile.${lower}.performance | grep "bytes prefetched" | awk '{print $2}' | sort -nr | head -n 1`
  echo $i,$size
done
