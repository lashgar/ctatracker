#!/bin/bash

texttocapture="total reads"
texttocapture2="total writes"

for bn in BFS BKP BPT EDS HSP MMA NN NNC RDC SRD #BFS BKP BPT RDC NNC NN #FLD FWL HSP LIB LPS MUM NNC NN SRD RDC;
#for bn in BFS BKP BPT FLD FWL HSP LIB LPS MUM NNC NN SRD RDC;
#for bn in FLD BFS SRD RDC BPT LIB FWL HSP HTW MUM NNC LPS BKP NN AES CP NQU RAY STO MTC ;
do
  row=""
  lower=$(echo $bn| tr '[:upper:]' '[:lower:]')
  for lt in newcta3 gtx480 #cta3_after_awhile gtx480 #cta3_prefbuff_16K gtx480
  #for lt in hermes hermes_perfgmem hermes_skip1024 hermes_skip256
  #for lt in gtx480 perfgmem ; # skipmem-256 skipmem-1024 # perfgmem ;
  do
    #echo "searching  $bn/log.${lt}.${lower}.performance for $texttocapture"
    nline=100
    a=""
    a=`cat $bn/log.${lt}.${lower}.performance | grep "$texttocapture" | tail -n 2 | awk '{print $3}'` ;
    a=`echo $a | sed 's/\ /\+/g' | bc`
    #drameff=`python -c "print ($a)/6"`
    #rowloc=`cat $bn/log.${lt}.${lower}.performance | grep "$texttocapture2" | tail -n 1 | awk '{print $5}'` ;
    row=$row$a, #$drameff,$rowloc
    #a=""
    #while [ "$a" == "" ] ; do nline=`expr $nline + 400` ; a=`tail -n $nline $bn/log.${lt}.${lower}.performance | grep $texttocapture2 | awk '{print $3}'` ;  done
    #row=$row$a,
  done
  #b=`tail -n 2000 $bn/log.skipmem-1024*performance | grep tot_ipc | awk '{print $3}'`
  #d=`tail -n 2000 $bn/log.perfgmem*formance | grep tot_ipc | awk '{print $3}'`
  #c=`tail -n 2000 $bn/log.gtx480*performance | grep tot_ipc | awk '{print $3}'`
  echo $row
  # $bn,$row
done
