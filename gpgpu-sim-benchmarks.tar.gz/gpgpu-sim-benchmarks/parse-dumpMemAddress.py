from optparse import OptionParser



parser = OptionParser()
parser.add_option("-f", "--file", dest="filename",
                  help="Path to output CU file", metavar="FILE", default="")
(options, args) = parser.parse_args()

if options.filename=="":
    print 'usage -f tracfile.txt' 
    exit(-1)

# parameter
linesize=128

# index pcs and store cta-address pairs
pc_pcs=[]
pc_ctas=[]
# index cta and store pc-address pairs
cta_pcs=[]
cta_ctas=[]

# open file
f=open(options.filename).readlines()

# start indexing
for l in f:
    # decompose the line
    pc=l.split()[1]
    cta=l.split()[3]
    ctax=cta[1:-1].split(',')[0]
    ctay=cta[1:-1].split(',')[1]
    ctaz=cta[1:-1].split(',')[2]
    wid=l.split()[5]
    addr=l.split()[7]
    #print '-'.join([pc,ctax,ctay,ctaz,addr])

    # update first indexing table
    try:
        id=pc_pcs.index(pc)
        pc_ctas[id].append((ctax+'-'+ctay+'-'+ctaz,int(addr)))
    except:
        pc_pcs.append(pc)
        pc_ctas.append([(ctax+'-'+ctay+'-'+ctaz,int(addr))])

    # update second indexing table
    try:
        id=cta_ctas.index(ctax+'-'+ctay+'-'+ctaz)
        cta_pcs[id].append((pc,int(addr)))
    except:
        cta_ctas.append(ctax+'-'+ctay+'-'+ctaz)
        cta_pcs.append([(pc,int(addr))])

for pcid in range(0,len(pc_pcs)):
    addr_min=[]
    addr_max=[]
    addr_cnt=[]
    #gc.collect()
    for cta in cta_ctas:
        min=-1
        max=-1
        cnt=0
        for k in pc_ctas[pcid]:
            if k[0]!=cta or k[1]==0:
                continue
            elif min==-1:
                min=k[1]
                max=k[1]
                cnt+=1
            elif k[1]>max:
                max=k[1]
                cnt+=1
            elif k[1]<min:
                min=k[1]
                cnt+=1
        addr_min.append(min)
        addr_max.append(max)
        addr_cnt.append(cnt)
    # calc mean
    sum=0
    for i in range(0,len(addr_min)):
        sum=sum+((addr_max[i]-addr_min[i])/linesize)
    mean=sum/float(len(addr_min))
    # calc variance
    sum=0
    for i in range(0,len(addr_min)):
        k=abs(mean-((addr_max[i]-addr_min[i])/linesize))
        k=k*k
        sum=sum+k
    variance=sum/float(len(addr_min))
    print pc_pcs[pcid]+' mean> '+str(mean)+' variance>'+str(variance)
    for i in range(0,len(addr_min)):
        print '\tcta['+cta_ctas[i]+']> rangeWidth:'+str((addr_max[i]-addr_min[i])/linesize)+', #addr:'+str(addr_cnt[i])

# gather statictics
print 'total pcs: '+str(len(pc_pcs))
print 'total ctas: '+str(len(cta_ctas))
