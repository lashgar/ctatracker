#!/bin/bash

source /global/scratch/alashgar/.bashrc

bn=$1
if [ "$bn" == "" ] ; then echo "unspecified benchmark name"; exit ; fi

echo "RUNNING: "$bn" ========================="
cd /global/scratch/alashgar/gpgpusim/gpuwattch/gpgpu-sim/ispass2009-benchmarks/$bn 
#vim run
make -B 
make clean_run 
bash run hermes_skip256
#bash run hermes_perfgmem &
#bash run hermes
#bash run skipmem-1024
#cat log.memtrace*performance | grep "cta>" > memtrace.txt
#rm log.memtrace* -f
#cd ..
