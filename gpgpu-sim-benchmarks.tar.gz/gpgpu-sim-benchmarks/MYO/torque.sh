#!/bin/sh
# Beginning of PBS batch script.
#PBS -l nodes=1:ppn=1
#PBS -o $HOME/gpgpu-sim/benchmarks/par-run-d1/$PBS_JOBID.log
#PBS -e $HOME/gpgpu-sim/benchmarks/par-run-d1/$PBS_JOBID.err
#PBS -N CompArch
#PBS -q batch 
#PBS -l walltime=96:00:00

echo "Opening the simulation directory on "`hostname` &> nohup-$PBS_JOBID
cd /share/users/alashgar/gpgpu-sim/benchmarks/par-run-d1/myocyte &>> nohup-$PBS_JOBID
echo "Starting simulation" &>> nohup-$PBS_JOBID
./myocyte.out 100 1 0 &>> nohup-$PBS_JOBID
echo "Draining out" &>> nohup-$PBS_JOBID
