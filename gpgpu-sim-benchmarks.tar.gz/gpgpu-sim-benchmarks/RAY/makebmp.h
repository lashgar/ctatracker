#ifndef _MAKEBMP_H_
#define _MAKEBMP_H_


void initialize_bmp(unsigned width, unsigned height, unsigned depth);

void create_bmp(unsigned *data);

#endif // _MAKEBMP_H_
