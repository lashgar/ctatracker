
cd /global/scratch/alashgar/gpgpusim/gpuwattch/gpgpu-sim/ispass2009-benchmarks

for bn in AES BFS CP LIB LPS MUM NN NQU RAY STO HTW HSP BKP RDC MTC FWL NNC BPT SRD FLD SCP MST HIS;
do
  echo "
#!/usr/local/bin/bash
#PBS -l walltime=24:00:00
#PBS -l nodes=1:ppn=1
cd /g01/scratch/alashgar/gpgpusim/gpuwattch/gpgpu-sim/ispass2009-benchmarks
bash singlerun.sh $bn &> torque.log.\$PBS_JOBID" > .TORQUE.PBS.$bn
done

for bn in AES BFS CP LIB LPS MUM NN NQU RAY STO HTW HSP BKP RDC MTC FWL NNC BPT SRD FLD SCP MST HIS;
do
qsub .TORQUE.PBS.$bn
done;
