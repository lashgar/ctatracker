#!/bin/bash

texttocapture=gpgpu_active_cycle_with_ilp
texttocapture2=gpgpu_active_cycle_with_tlp
texttocapture3=gpu_tot_sim_cycle
texttocapture4=W0_Idle

for bn in AES BFS CP LIB LPS MUM NN NQU RAY STO MMA EDS #NNC NN #FLD FWL HSP LIB LPS MUM NNC NN SRD RDC;
#for bn in BFS BKP BPT FLD FWL HSP LIB LPS MUM NNC NN SRD RDC;
#for bn in FLD BFS SRD RDC BPT LIB FWL HSP HTW MUM NNC LPS BKP NN AES CP NQU RAY STO MTC ;
do
  row=""
  lower=$(echo $bn| tr '[:upper:]' '[:lower:]')
  for lt in ilptlp
  #for lt in hermes hermes_perfgmem hermes_skip1024 hermes_skip256
  #for lt in gtx480 perfgmem ; # skipmem-256 skipmem-1024 # perfgmem ;
  do
    #echo "searching  $bn/log.${lt}.${lower}.performance for $texttocapture"
    nline=100
    a=""
    while [ "$a" == "" ] ; do nline=`expr $nline + 400` ; a=`tail -n $nline $bn/log.${lt}.${lower}.performance | grep $texttocapture | awk '{print $3}'` ;  done
    row=$row$a,

    nline=100
    a=""
    while [ "$a" == "" ] ; do nline=`expr $nline + 400` ; a=`tail -n $nline $bn/log.${lt}.${lower}.performance | grep $texttocapture2 | awk '{print $3}'` ;  done
    row=$row$a,

    nline=100
    a=""
    while [ "$a" == "" ] ; do nline=`expr $nline + 400` ; a=`tail -n $nline $bn/log.${lt}.${lower}.performance | grep $texttocapture3 | awk '{print $3}'` ;  done
    row=$row$a,

    nline=100
    a=""
    while [ "$a" == "" ] ; do nline=`expr $nline + 400` ; a=`tail -n $nline $bn/log.${lt}.${lower}.performance | grep $texttocapture4 | sed 's/\:/\ /g'` ;  done
    w0stl=`echo $a | awk '{print $2}'`
    w0idl=`echo $a | awk '{print $4}'`
    w0scr=`echo $a | awk '{print $6}'`
    row=$row$w0stl,$w0idl,$w0scr,
    for thd in {1..32}; do idx=`expr $thd \* 2`; idx=`expr $idx \+ 6`; export tmp=`echo $a | cut -d' ' -f$idx `; row=${row}${tmp}, ; done
    #row=$row$a,
  done
  #b=`tail -n 2000 $bn/log.skipmem-1024*performance | grep tot_ipc | awk '{print $3}'`
  #d=`tail -n 2000 $bn/log.perfgmem*formance | grep tot_ipc | awk '{print $3}'`
  #c=`tail -n 2000 $bn/log.gtx480*performance | grep tot_ipc | awk '{print $3}'`
  echo $bn,$row
done
