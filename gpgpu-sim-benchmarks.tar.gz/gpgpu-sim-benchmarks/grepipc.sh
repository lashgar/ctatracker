#!/bin/bash

texttocapture=tot_ipc
texttocapture2=gpgpu_n_mem_write_global

#for bn in HSP SRD NN NNC BFS BPT RDC BKP MMA #BFS BKP BPT RDC NNC NN #FLD FWL HSP LIB LPS MUM NNC NN SRD RDC;
#for bn in BFS EDS MMA NNC NN #BKP BPT EDS HSP MMA NN NNC RDC SRD
#for bn in SRD #MMA #BFS BKP BPT EDS HSP MMA NN NNC RDC SRD
#for perc in .50. #BFS BKP BPT EDS HSP MMA NN NNC RDC SRD
#for perc in .25. .50. .75. #BFS BKP BPT EDS HSP MMA NN NNC RDC SRD
#for bn in BFS BKP BPT EDS HSP MMA NN NNC RDC SRD
for bn in MMA SRD
#for bn in BFS BKP BPT FLD FWL HSP LIB LPS MUM NNC NN SRD RDC;
#for bn in FLD BFS SRD RDC BPT LIB FWL HSP HTW MUM NNC LPS BKP NN AES CP NQU RAY STO MTC ;
do
  #bn=SRD
  row=""
  lower=$(echo $bn| tr '[:upper:]' '[:lower:]')
  #for lt in cta3_Nprefbuff_16K_32asc cta3_Nprefbuff_32K_64asc cta3_Nprefbuff_64K_128asc cta3_Nprefbuff_128K_256asc 
  #for lt in cta3_75pdemand_Nprefbuff_8K_16asc cta3_75pdemand_Nprefbuff_16K_32asc cta3_75pdemand_Nprefbuff_32K_64asc cta3_75pdemand_Nprefbuff_64K_128asc cta3_75pdemand_Nprefbuff_128K_256asc 
  #for lt in newcta3_16K_32asc newcta3_32K_64asc newcta3_64K_128asc newcta3_128K_256asc #newcta3
  for lt in gtx480 #newcta3 #newcta2 newcta1
  #for lt in cta3_25pdemand_Nprefbuff_8K_16asc cta3_25pdemand_Nprefbuff_16K_32asc cta3_25pdemand_Nprefbuff_32K_64asc cta3_25pdemand_Nprefbuff_64K_128asc cta3_25pdemand_Nprefbuff_128K_256asc 
  #for lt in cta3_halfdemand_Nprefbuff_8K_16asc cta3_halfdemand_Nprefbuff_16K_32asc cta3_halfdemand_Nprefbuff_32K_64asc cta3_halfdemand_Nprefbuff_64K_128asc cta3_halfdemand_Nprefbuff_128K_256asc 
  #for lt in cta3_Nprefbuff_8K_16asc cta3_Nprefbuff_16K_32asc cta3_Nprefbuff_32K_64asc cta3_Nprefbuff_64K_128asc cta3_Nprefbuff_128K_256asc #cta3_prefbuff_8K cta3_prefbuff_16K cta3_prefbuff_64K
  #for lt in hermes hermes_perfgmem hermes_skip1024 hermes_skip256
  #for lt in gtx480 perfgmem ; # skipmem-256 skipmem-1024 # perfgmem ;
  do
    #echo "searching  $bn/log.${lt}.${lower}.performance for $texttocapture"
    nline=100
    a=""
    #echo $lt $perc
    #cat $bn/log.${lt}${perc}${lower}.performance | grep tot_ipc | wc -l
    #while [ "$a" == "" ] ; do nline=`expr $nline + 400` ; a=`tail -n $nline $bn/log.${lt}${perc}${lower}.performance | grep $texttocapture | awk '{print $3}'` ;  done
    while [ "$a" == "" ] ; do nline=`expr $nline + 400` ; a=`tail -n $nline $bn/log.${lt}.${lower}.performance | grep $texttocapture | awk '{print $3}'` ;  done
    row=$row$a,
    #a=""
    #while [ "$a" == "" ] ; do nline=`expr $nline + 400` ; a=`tail -n $nline $bn/log.${lt}.${lower}.performance | grep $texttocapture2 | awk '{print $3}'` ;  done
    #row=$row$a,
  done
  #b=`tail -n 2000 $bn/log.skipmem-1024*performance | grep tot_ipc | awk '{print $3}'`
  #d=`tail -n 2000 $bn/log.perfgmem*formance | grep tot_ipc | awk '{print $3}'`
  #c=`tail -n 2000 $bn/log.gtx480*performance | grep tot_ipc | awk '{print $3}'`
  echo $bn,$row
done
