#!/bin/bash

for bn in AES BFS CP LIB LPS MUM NN NQU RAY STO ;
do
    row=""
    for lt in gtx480 
    do
        a=`cat $bn/log.${lt}*performance | grep -e gridDim | awk '{print $10","}'`  
        b=`cat $bn/log.${lt}*performance | grep -e "CTA/core" | awk '{print $5}'`  
        row=$row$a$b,
    done
    #b=`tail -n 2000 $bn/log.skipmem-1024*performance | grep tot_ipc | awk '{print $3}'`
    #d=`tail -n 2000 $bn/log.perfgmem*formance | grep tot_ipc | awk '{print $3}'`
    #c=`tail -n 2000 $bn/log.gtx480*performance | grep tot_ipc | awk '{print $3}'`
    echo $bn,$row
done
