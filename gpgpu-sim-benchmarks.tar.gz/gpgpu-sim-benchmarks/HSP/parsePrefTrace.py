

for x in range(0,24):
    for y in range(0,24):
        cta=str(x)+"-"+str(y)+"-0"
        prefetched=[]
        accessed=[]
        for l in open('log.trace').readlines():
            [g, a,b,c,d,e]=l.split()
            if (b+"-"+c+"-"+d)!=cta:
                continue
            if a=="P":
                prefetched.append(e)
            elif a=="F":
                accessed.append(e)
            else:
                print "error!"
        
        total=0
        matched=0
        for k in accessed:
            for l in prefetched:
                if l==k:
                    matched+=1
                    break
            total+=1
        
        #print 'prefetched> '+str(len(prefetched))+' accessed> '+str(len(accessed))
        print cta+' accuracy> '+str(matched/float(total))
