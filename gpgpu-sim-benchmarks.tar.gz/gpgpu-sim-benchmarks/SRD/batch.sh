#!/bin/bash

source /global/scratch/alashgar/.bashrc

count=0
#for bn in MUM NN STO NQU ;
#for bn in AES BFS CP LIB LPS MUM NN NQU RAY STO ; # 4hour
#for bn in HTW HSP BKP ; # 12hour
#for bn in RDC MTC FWL NNC BPT SRD ; # 12hour
#for bn in FLD SCP MST HIS; # 48hour
# for bn in STL; # 48hour
#for bn in AES BFS CP LIB LPS MUM NN NQU RAY STO RDC MTC FWL;
for bn in SCP MST HIS;
#all for bn in AES BFS CP LIB LPS MUM NN NQU RAY STO HTW HSP BKP RDC MTC FWL NNC BPT SRD FLD SCP MST HIS;
do
    echo "RUNNING: "$bn" ========================="
    cd /global/scratch/alashgar/gpgpusim/gpuwattch/gpgpu-sim/ispass2009-benchmarks/$bn 
    #vim run
    make -B 
    make clean_run 
    bash run hermes_perfgmem &
    #bash run hermes
    #bash run skipmem-1024
    #cat log.memtrace*performance | grep "cta>" > memtrace.txt
    #rm log.memtrace* -f
    #cd ..
    sleep 30

    count=`expr $count + 1`
    if [ "$count" == "4" ] ; then wait ; count=0; fi
done

wait
