#!/bin/bash

source /global/scratch/alashgar/.bashrc

count=0
#for bn in MUM NN STO NQU ;
#for bn in AES BFS CP LIB LPS MUM NN NQU RAY STO ; # 4hour
#for bn in HTW HSP BKP ; # 12hour
#for bn in RDC MTC FWL NNC BPT SRD ; # 12hour
#for bn in FLD SCP MST HIS; # 48hour
# for bn in STL; # 48hour
#for bn in AES BFS CP LIB LPS MUM NN NQU RAY STO RDC MTC FWL;
#for bn in BFS BPT RDC HSP SRD
#for bn in SCP MST HIS;
for bn in AES BFS CP LIB LPS MUM NN NQU RAY STO HTW HSP BKP RDC MTC FWL NNC BPT SRD FLD SCP MST HIS EDS MMA_SDK MMM_SDK MMA MYO WP STL; 
#for bn in NN #AES BFS CP LIB LPS MUM NN NQU RAY STO HTW HSP BKP RDC MTC FWL NNC BPT SRD FLD SCP MST HIS;
#for bn in BFS BKP BPT EDS HSP MMA NN NNC RDC SRD
#for bn in MMA_SDK #MMA
#for bn in SRD #BKP #RDC NNC BPT FLD NN #FWL #NN #BPT #BFS #SRD
#for bn in SRD #MMA #NN NNC EDS BFS SRD HSP BKP BPT RDC #NN NNC BFS BPT RDC BKP MMA EDS #SRD AES BFS CP LIB LPS MUM NN NQU RAY STO MMA EDS HTW HSP BKP RDC MTC FWL NNC BPT SRD FLD SCP MST HIS ;
do
  echo "RUNNING: "$bn" ========================="
  cd /home/alashgar/simulators/ctatracker/ctatracker/ispass2009-benchmarks/$bn
  #vim run
  make clean_run  clean
  rm log.* -f
  #bash run ctatracker_inject &
  #bash run ctatracker_injectNsync &
  #bash run cta3_half &
  #bash run cta3_after_awhile &
  #bash run cta3_75pdemand_Nprefbuff_128K_256asc &
  #bash run newcta3_l1l2l3l4_128K_256asc      #test_l1al2al3a #darksili_lowfreq_350 &
  #bash run gtx480 #newcta3_16K_32asc
  #export nm=`echo $bn | tr '[:upper:]' '[:lower:]'`
  #mv log.newcta3.$nm.performance log.newcta3_128K_256asc.$nm.performance
  #bash run perfect_mem &
  #bash run batch_cta3 &
  #mfailure_cta3 &
  #bash run test_afterawhile_base &
  #bash run hermes
  #bash run skipmem-1024
  #cat log.memtrace*performance | grep "cta>" > memtrace.txt
  #rm log.memtrace* -f
  #cd ..
  #sleep 10

  #count=`expr $count + 1`
  #if [ "$count" == "5" ] ; then wait ; count=0; fi
done

wait
