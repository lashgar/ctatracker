#!/usr/local/bin/bash

#for i in SRD BKP RDC NNC BPT NN BPT BFS MMA EDS HSP ;
for i in BFS BKP BPT EDS HSP MMA NN NNC RDC SRD
do
  lower=$(echo $i | tr '[:upper:]' '[:lower:]')
  size=`cat $i/log.newcta3.${lower}.performance | grep "covered" | awk '{print $4}' | tail -n 1`
  #size=`cat $i/log.cta3_after_awhile.${lower}.performance | grep "covered" | awk '{print $4}' | tail -n 1`
  echo $i,$size
done
